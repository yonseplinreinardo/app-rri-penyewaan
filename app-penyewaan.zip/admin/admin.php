<?php
session_start();
require "../functions.php";
require "../session.php";
if ($role !== 'Admin') {
  header("location:../login.php");
};

// Pagination
$jmlHalamanPerData = 10;
$jumlahData = count(query("SELECT * FROM tb_admin"));
$jmlHalaman = ceil($jumlahData / $jmlHalamanPerData);

if (isset($_GET["halaman"])) {
  $halamanAktif = $_GET["halaman"];
} else {
  $halamanAktif = 1;
}

$awalData = ($jmlHalamanPerData * $halamanAktif) - $jmlHalamanPerData;

$admin = query("SELECT * FROM tb_admin LIMIT $awalData, $jmlHalamanPerData");


if (isset($_POST["simpan"])) {
  if (tambahAdmin($_POST) > 0) {
    echo "<script>
  alert('Berhasil DiTambahkan');
</script>";
  } else {
    echo "<script>
  alert('Gagal DiTambahkan');
</script>";
  }
}

if (isset($_POST["edit"])) {
  if (editAdmin($_POST) > 0) {
    echo "<script>
  alert('Berhasil DiTambahkan');
</script>";
  } else {
    echo "<script>
  alert('Gagal DiTambahkan');
</script>";
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.19.0/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

  <title>ADMIN | RRI BANJARMASIN</title>
</head>
<style>
  .hidden {
    display: none;
  }

  i {
    color: white;
    text-align: left;
    font-size: larger;
    font-style: normal;
  }

  li {
    text-align: left;

  }
</style>

<body>
  <div class="container-fluid">
    <div class="row min-vh-100">
      <div class="sidebar col-2 bg-secondary">
        <!-- Sidebar -->
        <h5 class="mt-5 judul text-center">ADMIN</h5>
        <ul class="list-group list-group-flush">
          <li class="list-group-item bg-transparent"><a href="home.php">Home</a></li>
          <li class="list-group-item bg-transparent"><a href="member.php">Data User</a></li>
          <li class="list-group-item bg-transparent"><a href="produk.php">Data Produk</a></li>
          <li class="list-group-item bg-transparent"><a href="pesan.php">Data Penyewaan</a></li>
          <li class="list-group-item bg-transparent"><a href="admin.php">Data Admin</a></li>
        </ul>
        <ul class="list-group list-group-flush btn" id="myList" onclick="toggleOptions()"><i>Laporan</i>
          <li class="list-group-item bg-transparent hidden"></li>
          <li class="list-group-item bg-transparent list-group-item hidden"><a href="export-member.php">Laporan User</a></li>
          <li class="list-group-item bg-transparent list-group-item hidden"><a href="export-produk.php">Laporan Produk</a></li>
          <li class="list-group-item bg-transparent list-group-item hidden"><a href="export.php">Laporan Penyewaan</a></li>
          <li class="list-group-item bg-transparent list-group-item hidden"><a href="export-admin.php">Laporan Admin</a></li>
        </ul>
        <a href="../logout.php" class="mt-5 btn btn-inti text-dark">Logout</a>
      </div>
      <div class="col-10 p-5 mt-5">
        <!-- Konten -->
        <h3 class="judul">Data Admin</h3>
        <hr>
        <!-- <a href="export-admin.php" class="btn btn-inti mt-5">Cetak</a><br> -->
        <button class="btn btn-inti" data-bs-toggle="modal" data-bs-target="#tambahModal">Tambah</button>
        <br><br>
        <!-- Modal Tambah -->
        <div class="modal fade" id="tambahModal" tabindex="-1" aria-labelledby="tambahModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="tambahModalLabel">Tambah Admin</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <form action="" method="post">
                <div class="modal-body">
                  <!-- konten form modal -->
                  <div class="row justify-content-center align-items-center">
                    <div class="col">
                      <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" id="exampleInputPassword1">
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" id="exampleInputPassword1">
                      </div>
                    </div>
                    <div class="col">
                      <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Nama Lengkap</label>
                        <input type="text" name="nama" class="form-control" id="212279_exampleInputPassword1">
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">No Hp</label>
                        <input type="number" name="hp" class="form-control" id="exampleInputPassword1">
                      </div>
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Email</label>
                      <input type="email" name="email" class="form-control" id="exampleInputPassword1">
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                  <button type="submit" class="btn btn-primary" name="simpan" id="simpan">Simpan</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!-- End Modal Tambah -->
        <table id="example" class="table table-striped" style="width:100%">
          <thead class="table-inti">
            <tr>
              <th scope="col">No</th>
              <th scope="col">Aksi</th>
              <th scope="col">Username</th>
              <th scope="col">Nama Lengkap</th>
              <th scope="col">Email</th>
              <th scope="col">No Hp</th>
            </tr>
          </thead>
          <tbody class="text">
            <?php $i = 1; ?>
            <?php foreach ($admin as $row) : ?>
              <tr>
                <th scope="row"><?= $i++; ?></th>
                <td>
                  <div class="d-flex order-actions">
                    <!-- <a href="./controller/hapusAdmin.php?id=<?= $row["id_admin"]; ?>" class="btn btn-primary mx-1"><i class="fa-solid fa-edit"></i></a> -->
                    <a href="./controller/hapusAdmin.php?id=<?= $row["id_admin"]; ?>" class="btn btn-danger"><i class="fa-solid fa-trash"></i></a>
                </td>
      </div>
      <td><?= $row["username"]; ?></td>
      <td><?= $row["nama_admin"]; ?></td>
      <td><?= $row["email_admin"]; ?></td>
      <td><?= $row["nohp_admin"]; ?> </td>


      <!-- Edit Modal -->
      <div class="modal fade" id="editModal<?= $row["id_Admin"]; ?>" tabindex="-1" aria-labelledby="tambahModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="tambahModalLabel">Edit Admin <?= $row["nama_admin"]; ?></h5>
            </div>
            <form action="" method="post">
              <input type="hidden" name="id" class="form-control" id="exampleInputPassword1" value="<?= $row["id_admin"]; ?>>">
              <div class="modal-body">
                <!-- konten form modal -->
                <div class="row justify-content-center align-items-center">
                  <div class="mb-3">
                    <img src="../img/futsal.jpg" alt="gambar lapangan" class="img-fluid">
                  </div>
                  <div class="col">
                    <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Username</label>
                      <input type="text" name="username" class="form-control" id="exampleInputPassword1" value="<?= $row["username"]; ?>">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Password</label>
                      <input type="password" name="password" class="form-control" id="exampleInputPassword1" value="<?= $row["password_admin"]; ?>">
                    </div>
                  </div>
                  <div class="col">
                    <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Nama Lengkap</label>
                      <input type="text" name="nama" class="form-control" id="exampleInputPassword1" value="<?= $row["nama_admin"]; ?>">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">No Hp</label>
                      <input type="number" name="hp" class="form-control" id="exampleInputPassword1" value="<?= $row["nohp_admin"]; ?>">
                    </div>
                    <d212279_no_handiv class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Email</label>
                      <input type="email" name="email" class="form-control" id="exampleInputPassword1" value="<?= $row["email_admin"]; ?>">
                  </div>
                </div>

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-primary" name="edit" id="edit">Simpan</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <!-- End Modal Tambah -->
      </tr>
    <?php endforeach; ?>
    </tbody>
    </table>

    <ul class="pagination">
      <?php if ($halamanAktif > 1) : ?>
        <li class="page-item">
          <a href="?halaman=<?= $halamanAktif - 1; ?>" class="page-link">Previous</a>
        </li>
      <?php endif; ?>

      <?php for ($i = 1; $i <= $jmlHalaman; $i++) : ?>
        <?php if ($i == $halamanAktif) : ?>
          <li class="page-item active"><a class="page-link" href="?halaman=<?= $i; ?>"><?= $i; ?></a></li>
        <?php else : ?>
          <li class="page-item "><a class="page-link" href="?halaman=<?= $i; ?>"><?= $i; ?></a></li>
        <?php endif; ?>
      <?php endfor; ?>

      <?php if ($halamanAktif < $jmlHalaman) : ?>
        <li class="page-item">
          <a href="?halaman=<?= $halamanAktif + 1; ?>" class="page-link">Next</a>
        </li>
      <?php endif; ?>
    </ul>

    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
    <script>
      new DataTable('#example');
    </script>
    <script>
      function toggleOptions() {
        var options = document.querySelectorAll('#myList li:not(:first-child)');

        options.forEach(function(option) {
          option.classList.toggle('hidden');
        });
      }
    </script>

</body>

</html>