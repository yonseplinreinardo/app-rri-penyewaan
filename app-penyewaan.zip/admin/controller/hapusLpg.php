<?php
require "../../functions.php";
$id_lap = $_GET["id"];

if (hapusProduk($id_lap) > 0) {
  echo "
  <script>
    alert('Data Berhasil Dihapus');
    document.location.href = '../produk.php'; 
  </script>
  ";
} else {
  echo "
  <script>
    alert('Data Gagal Dihapus');
    document.location.href = '../produk.php'; 
  </script>
  ";
}
